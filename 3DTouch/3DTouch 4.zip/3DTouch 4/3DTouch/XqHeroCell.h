//
//  XqHeroCell.h
//  3DTouch
//
//  Created by 弓虽_子 on 15/12/26.
//  Copyright © 2015年 弓虽_子. All rights reserved.
//

#import <UIKit/UIKit.h>
@class XqHeroItem;
@interface XqHeroCell : UITableViewCell

@property (nonatomic, strong) XqHeroItem *heroItem;


@end
